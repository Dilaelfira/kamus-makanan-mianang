from flask import Flask, render_template, request
from kamus_makanan_minangkabau import cari_kata

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    hasil = ""
    if request.method == 'POST':
        kata = request.form['kata']
        hasil = cari_kata(kata)
    return render_template('index.html', hasil=hasil)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
